﻿using System;
using Android.App;
using Android.Content;
using Android.Runtime;
using Android.OS;
using Android.Views;
using Android.Widget;
using Java.Lang;
using System.Collections.Generic;
using Android.Graphics;

namespace scripting.Droid
{
    public class TextImageAdapterX : BaseAdapter
    {
        JavaList<string> m_javaItems;
        //JavaList<int> m_javapics;
        List<string> m_items;
        List<int> m_pics;
        string m_first;

        Context m_context;
        LayoutInflater m_inflater;
        View m_view;

        Color m_bgcolor = Color.ParseColor("#91F6FF");
            //Color.Transparent;

        public TextImageAdapterX(Context context,
                                View view = null)
            //: base(context, Resource.Layout.spinner)
        {
            m_context = context;
            m_view = view;
        }

        public void SetItems(List<string> items, string first = null)
        {
            //m_items = UtilsDroid.GetJavaStringList(items, first);
            m_first = first;
            m_items = items;
            m_javaItems = UtilsDroid.GetJavaStringList(items);
            if (first != null) {
                m_items.Insert(0, first);
            }
        }
        public void SetPics(List<string> pics)
        {
            //m_pics = UtilsDroid.GetJavaPicList(pics, first);
            m_pics = UtilsDroid.GetPicList(pics, m_first);
        }

        public override int Count {
            get {
                if (m_items != null) {
                    return m_items.Count;
                }
                if (m_pics != null) {
                    return m_pics.Count;
                }
                return 0;
            }
        }

        public override Java.Lang.Object GetItem(int position)
        {
            //if (m_items == null || m_items.Count <= position) {
            //    return null;
            //}
            //return new Java.Lang.String(m_items[position]);
            return m_javaItems[position];
        }

        public override long GetItemId(int position)
        {
            return position;
        }

        public int NameToPosition(string name)
        {
            if (m_items == null) {
                return -1;
            }
            for (int i = 0; i < m_items.Count; i++) {
                if (m_items[i] == name) {
                    return i;
                }
            }
            return 0;
        }

        public override View GetDropDownView(int position, View convertView, ViewGroup parent)
        {
            return base.GetDropDownView(position, convertView, parent);
                //GetView(position, convertView, parent);
        }
        public override View GetView(int position, View convertView, ViewGroup parent)
        {
            if (m_inflater == null) {
                m_inflater = (LayoutInflater)m_context.GetSystemService(Context.LayoutInflaterService);
            }
            if (convertView == null) {
                convertView = m_inflater.Inflate(Resource.Layout.spinner, parent, false);
                //return convertView;
            }
 
            /*LinearLayout layout = new LinearLayout(m_context);
            layout.SetBackgroundColor(m_bgcolor);//Android.Graphics.Color.ParseColor("#91F6FF"));
            layout.LayoutParameters = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WrapContent, ViewGroup.LayoutParams.WrapContent);
            layout.DescendantFocusability = DescendantFocusability.BlockDescendants;
            layout.Focusable = false;*/
            //convertView.Focusable = false;

            if (m_pics != null && position < m_pics.Count && m_pics[position] >= 0) {
                ImageView imageView = convertView.FindViewById<ImageView>(Resource.Id.spinner_image);
                //ImageView imageView = new ImageView(m_context);
                imageView.SetImageResource(m_pics[position]);
                //imageView.Focusable = false;
                //imageView.Clickable = false;
                //layout.AddView(imageView);
            }

            if (m_items != null && position < m_items.Count) {
                //TextView textView = new TextView(m_context); 
                TextView textView = convertView.FindViewById<TextView>(Resource.Id.spinner_text);
                textView.Text = m_items[position];
                //textView.SetBackgroundColor(m_bgcolor);
                //textView.Focusable = false;
                //textView.Clickable = false;
                //layout.AddView(textView);
            }

            //convertView = layout;
            return convertView;
        }
    }

    public class SpinnerClickListener : Java.Lang.Object, AdapterView.IOnItemSelectedListener
    {

        void AdapterView.IOnItemSelectedListener.OnItemSelected(AdapterView parent, View view, int position, long id)
        {
            int i = 0;
        }

        void AdapterView.IOnItemSelectedListener.OnNothingSelected(AdapterView parent)
        {
            int i = 2;
        }
    }

    public class TextImage
    {
        private string m_name;
        private int m_image;
        public TextImage(string name, int image = -1)
        {
            m_name = name;
            m_image = image;
        }
        public string Name {
            get { return m_name; }
            set { m_name = value; }
        }
        public int Image {
            get { return m_image; }
            set { m_image = value; }
        }
        public string AsString()
        {
            string result = "Name: " + (string.IsNullOrWhiteSpace(Name) ? "NULL" : Name);
            result += " Image: " + Image;
            return result;
        }
    }
}
